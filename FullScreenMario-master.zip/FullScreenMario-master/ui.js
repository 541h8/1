var loadstart, isLocal, elemGame, game, body, elemSelect;

function start() {
  if(window.loadstart) return;
  window.loadstart = true;
  setLocalStatus();
  setReferences();
  setMapSelector();
  setLevelEditor();
  setOptions();
  setKeyMappingMenu();
  setCheats();
}

function setLocalStatus() {
  window.isLocal = window.location.origin == "file://";
}

function setReferences() {
  window.elemGame = document.getElementById("game");
  window.game = window.elemGame.contentWindow;
  if(!isLocal) window.game.parentwindow = window;
  window.body = document.body;
  window.elemSelect = document.getElementById("in_mapselect");
}

function setMapSelector(timed) {
  if(!window.elemSelect && !timed)
	return setTimeout(function(){ setMapSelector(true); }, 350);
  var innerHTML = "", i, j;
  for(i=1;i<=8;++i)
	for(j=1;j<=4;++j)
	  innerHTML += createAdderMap(i,j);
  elemSelect.innerHTML += innerHTML + createAdderBigMap("随机生成关卡！","setGameMapRandom");
  if(!isLocal) {
	game.parentwindow = window;
	for(i=1;i<=8;++i)
	  for(j=1;j<=4;++j)
		if(game["World"+i+String(j)] && document.getElementById("maprect"+i+","+j))
		  document.getElementById("maprect"+i+","+j).className = "maprect";
  }
}

function createAdderMap(i,j) {
  return "<div class='maprectout'><div id='maprect"+i+","+j+"' class='maprect"+(isLocal?"":" off")+"' onclick='setGameMap("+i+","+j+")'>"+i+"-"+j+"</div></div>";
}

function createAdderBigMap(name,onclick,giant) {
  return "<div class='maprectout'><div class='maprect big "+(giant?"giant":"")+"' onclick='"+onclick+"()'>"+name+"</div></div>";
}

function setGameMap(one,two) {
  if(document.getElementById("maprect"+one+","+two).className != "maprect") return;
  game.postMessage({type:"setMap",map:[one,two]},"*");
  game.focus();
}

function onMapLoad(one,two) {
  var e = document.getElementById("maprect"+one+","+two);
  if(e) e.className = "maprect";
}

function setGameMapRandom() {
  game.postMessage({type:"setMap",map:["Random","Overworld"]},"*");
  game.focus();
}

function setLevelEditor() {
  var out = document.getElementById("in_editor");
  out.innerHTML = "为什么要玩任天堂的？<br/>" + createAdderBigMap("自己制作关卡吧！","startEditor",true) + "<br/>完成后可以保存为文本文件。";
}

function startEditor() {
  game.postMessage({type:"startEditor"},"*");
  game.focus();
}

function setOptions() {
  var out = document.getElementById("in_options");
  var opts = ["静音","路易吉","快进"];
  var html = "";
  for(var i in opts)
	html += "<div class='maprectout' onclick='toggleGame(\""+opts[i]+"\")'><div class='maprect big larger'>切换"+opts[i]+"</div></div><br/>";
  out.innerHTML = html + "<br/>更多功能即将推出！";
}

function setKeyMappingMenu() {
  var out = document.getElementById("in_keymapping");
  var keys = ["上","下","左","右","加速","暂停","静音"];
  var html = "";
  for(var i in keys)
	html += "<div class='maprectout'><div class='maprect big larger'>"+keys[i]+"<input onkeydown='setKey(event)' type='texte' id='"+keys[i].toLowerCase()+"' readonly></input></div></div><br/>";
  out.innerHTML = html;
}

function setKey(e) {
  game.postMessage({type:"setKey",action:e.target.id,keyCode:e.keyCode},"*");
  e.target.value = e.keyCode;
}

function toggleGame(me) {
  game.postMessage({type:"toggleOption",option:me},"*");
}

function setCheats() {
  console.log("你好！感谢你玩全屏马里奥！");
  console.log("输入 displayCheats() 查看常用作弊码。");
  window.cheats = {
	切换关卡:"game.setMap(#,#)",
	快进:"game.fastforward()",
	加命:"game.gainLife(5)",
	变大:"game.playerShroom(game.player)",
	无敌星:"game.playerStar(game.player)",
	随机关卡:"game.setMapRandom()",
	无限时间:"game.data.time.amount=Infinity"
  };
}

function displayCheats() {
  for(var i in cheats) console.log(i+" → "+cheats[i]);
  return "玩得开心！";
}